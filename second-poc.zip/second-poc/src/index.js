import React from 'react';
import ReactDOM from 'react-dom';
 import Home from './component/Home';

ReactDOM.render( <Home />,  document.getElementById('root'));
